# fabric-manage-item-access.ps1
# Final Master Access Orchestrator with Idempotent Pre-Check (GET-then-POST/PATCH)
param (
    [string]$workspaceId,
    [string]$token,
    [string]$itemName,
    [string]$itemType,
    [string]$principalName,
    [string]$principalIdFromParam,
    [string]$principalType,
    [string]$permissions
)

$headers = @{
    Authorization = "Bearer $token"
    "Content-Type" = "application/json"
}

Write-Host "`n--- Access Orchestrator: $itemName ($itemType) ---"

# 1. Resolve Principal ID
$principalId = $principalIdFromParam
if ([string]::IsNullOrWhiteSpace($principalId) -or $principalId -eq "NONE") {
    Write-Host "Resolving Object ID for $principalName (Type: $principalType)..."
    try {
        if ($principalType -eq "Group") { $principalId = az ad group show --group "$principalName" --query id -o tsv }
        elseif ($principalType -eq "User" -or $principalType -eq "Email") { 
            $principalId = az ad user show --id "$principalName" --query id -o tsv 
        } elseif ($principalType -eq "ServicePrincipal") { 
            $principalId = az ad sp list --display-name "$principalName" --query "[0].id" -o tsv
            if ([string]::IsNullOrWhiteSpace($principalId)) { $principalId = az ad sp show --id "$principalName" --query id -o tsv }
        }
    } catch {
        Write-Warning "Direct lookup failed. Trying identifier as ID..."
        $principalId = $principalName
    }
}
if ([string]::IsNullOrWhiteSpace($principalId)) { Write-Error "CRITICAL: Could not resolve Principal Object ID."; exit 1 }
Write-Host "Resolved Object ID: $principalId"

# 2. Discover Target Item(s)
Write-Host "Searching for '$itemName' in Workspace: $workspaceId..."
$itemsUrl = "https://api.fabric.microsoft.com/v1/workspaces/$workspaceId/items"
try {
    $items = Invoke-RestMethod -Uri $itemsUrl -Method Get -Headers $headers
    $targetItem = $items.value | Where-Object { $_.displayName -eq $itemName -and $_.type -eq $itemType }
} catch {
    Write-Error "Failed to reach Fabric REST API: $($_.Exception.Message)"
    exit 1
}

if ($null -eq $targetItem) {
    Write-Error "Item '$itemName' ($itemType) not found."
    exit 1
}
$itemId = $targetItem.id
Write-Host "Found Item ID: $itemId"

# Lakehouse related item discovery (SQL Endpoint / Semantic Model)
$targetItems = @($targetItem)
if ($itemType -eq "Lakehouse") {
    $related = $items.value | Where-Object { 
        ($_.displayName -eq $itemName -or $_.displayName -eq "${itemName} (SQL Endpoint)") -and 
        ($_.type -eq "SQLEndpoint" -or $_.type -eq "SemanticModel")
    }
    if ($null -ne $related) {
        $targetItems += $related
        Write-Host "Discovered $($related.Count) related items (SQL Endpoint/Semantic Model)."
    }
}

# 3. Permission Alignment Function with IDEMPOTENCY check
function Align-Permissions {
    param($item)
    
    Write-Host "`n>>> Aligning Permissions: $($item.displayName) ($($item.type))"
    $permsArray = $permissions.Split(",") | ForEach-Object { "$($_.Trim())" }
    
    # Power BI mapping
    $pbiRight = "Read"
    if ($permsArray -contains "Write") { $pbiRight = "ReadWrite" }
    if ($permsArray -contains "Reshare") { $pbiRight = $pbiRight + "Reshare" }
    if ($permsArray -contains "Admin") { $pbiRight = "Admin" }
    
    $pbiPType = $principalType
    if ($pbiPType -eq "ServicePrincipal") { $pbiPType = "App" }
    elseif ($pbiPType -eq "Email") { $pbiPType = "User" }

    $fabricBody = @{ principal = @{ id = $principalId; type = $principalType }; permissions = $permsArray } | ConvertTo-Json -Depth 5
    $pbiArtifactBody = @{ identifier = $principalId; principalType = $pbiPType; artifactUserAccessRight = $pbiRight } | ConvertTo-Json
    $pbiDatasetBody = @{ identifier = $principalId; principalType = $pbiPType; datasetUserAccessRight = $pbiRight } | ConvertTo-Json

    $strategies = @(
        @{ name = "Fabric Core V1"; url = "https://api.fabric.microsoft.com/v1/workspaces/$workspaceId/items/$($item.id)/permissions"; method = "POST"; body = $fabricBody; type = "fabric" },
        @{ name = "PBI Datasets Fallback"; url = "https://api.powerbi.com/v1.0/myorg/groups/$workspaceId/datasets/$($item.id)/users"; method = "POST"; body = $pbiDatasetBody; type = "dataset" },
        @{ name = "PBI Artifacts Fallback"; url = "https://api.powerbi.com/v1.0/myorg/groups/$workspaceId/artifacts/$($item.id)/users"; method = "POST"; body = $pbiArtifactBody; type = "artifact" }
    )

    $success = $false
    foreach ($api in $strategies) {
        Write-Host "Checking strategy: $($api.name)..."
        
        # IDEMPOTENCY: Check if the principal already exists on this item
        $checkUrl = $api.url # Usually GET is the same URL
        try {
            $existing = Invoke-RestMethod -Uri $checkUrl -Method Get -Headers $headers
            $found = $null
            
            if ($api.type -eq "fabric") {
                $found = $existing.value | Where-Object { $_.principal.id -eq $principalId }
            } else {
                $found = $existing.value | Where-Object { $_.identifier -eq $principalId -or $_.emailAddress -eq $principalName }
            }

            if ($null -ne $found) {
                Write-Host "Principal already exists on $($item.displayName). Skipping assignment to avoid conflict."
                $success = $true
                break
            }
        } catch {
            Write-Host "GET Permissions failed for $($api.name). Proceeding with assignment attempt."
        }

        # Attempt assignment if not found (or if GET failed)
        try {
            Invoke-RestMethod -Uri $api.url -Method $api.method -Headers $headers -Body $api.body -ErrorAction Stop
            Write-Host "SUCCESS: Aligned via $($api.name)."
            $success = $true
            break
        } catch {
            $statusCode = 0
            if ($null -ne $_.Exception.Response) { $statusCode = [int]$_.Exception.Response.StatusCode }
            
            if ($statusCode -eq 409) {
                Write-Host "Conflict detected (already exists). Skipping to next strategy or completing."
                $success = $true
                break
            } else {
                Write-Host "Strategy $($api.name) returned Status: $statusCode - $($_.Exception.Message)"
            }
        }
    }
    return $success
}

# 4. Execute Loop
$overallSuccess = $true
foreach ($item in $targetItems) {
    if (-not (Align-Permissions -item $item)) { $overallSuccess = $false }
}

if (-not $overallSuccess) {
    Write-Warning "`nNOT ALL ITEMS COULD BE ALIGNED VIA REST API."
    exit 1
}

Write-Host "`n--- Access Management Alignment Finalized Successfully ---"
