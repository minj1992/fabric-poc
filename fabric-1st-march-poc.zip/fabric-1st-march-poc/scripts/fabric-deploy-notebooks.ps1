# fabric-deploy-notebooks.ps1
# Purpose: Import or Update Notebooks in Microsoft Fabric via REST API
param (
    [string]$workspaceId,
    [string]$token,
    [string]$notebooksPath
)

$headers = @{
    Authorization = "Bearer $token"
    "Content-Type" = "application/json"
}

# 1. Get List of existing items
$uri = "https://api.fabric.microsoft.com/v1/workspaces/$workspaceId/items"
$response = Invoke-RestMethod -Uri $uri -Method Get -Headers $headers

# 2. Iterate through files in artifacts/notebooks
$files = Get-ChildItem -Path $notebooksPath -Filter *.ipynb
foreach ($file in $files) {
    $displayName = $file.BaseName
    $base64Content = [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($file.FullName))

    $existing = $response.value | Where-Object { $_.displayName -eq $displayName -and $_.type -eq "Notebook" }

    if ($null -eq $existing) {
        Write-Host "Creating Notebook: $displayName..."
        $createUri = "https://api.fabric.microsoft.com/v1/workspaces/$workspaceId/items"
        $body = @{
            displayName = $displayName
            type        = "Notebook"
            definition  = @{
                parts = @(
                    @{
                        path = "notebook-content.py"
                        payload = $base64Content
                        payloadType = "Base64"
                    }
                )
            }
        } | ConvertTo-Json -Depth 10
        Invoke-RestMethod -Uri $createUri -Method Post -Headers $headers -Body $body
    } else {
        Write-Host "Notebook '$displayName' already exists. Updating definition..."
        $itemId = $existing.id
        $updateUri = "https://api.fabric.microsoft.com/v1/workspaces/$workspaceId/items/$itemId/updateDefinition"
        $body = @{
            definition = @{
                parts = @(
                    @{
                        path = "notebook-content.py"
                        payload = $base64Content
                        payloadType = "Base64"
                    }
                )
            }
        } | ConvertTo-Json -Depth 10
        Invoke-RestMethod -Uri $updateUri -Method Post -Headers $headers -Body $body
    }
}
