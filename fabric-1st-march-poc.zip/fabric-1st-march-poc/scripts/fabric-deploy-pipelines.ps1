# fabric-deploy-pipelines.ps1
# Purpose: Import or Update Data Pipelines in Microsoft Fabric via REST API
param (
    [string]$workspaceId,
    [string]$token,
    [string]$pipelinesPath
)

$headers = @{
    Authorization = "Bearer $token"
    "Content-Type" = "application/json"
}

# 1. Get List of existing items
$uri = "https://api.fabric.microsoft.com/v1/workspaces/$workspaceId/items"
$response = Invoke-RestMethod -Uri $uri -Method Get -Headers $headers

# 2. Iterate through files in artifacts/pipelines
$files = Get-ChildItem -Path $pipelinesPath -Filter *.json
foreach ($file in $files) {
    $content = Get-Content -Path $file.FullName | ConvertFrom-Json
    $displayName = $content.displayName
    $base64Content = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($content.definition.pipelineContent))

    $existing = $response.value | Where-Object { $_.displayName -eq $displayName -and $_.type -eq "DataPipeline" }

    if ($null -eq $existing) {
        Write-Host "Creating Data Pipeline: $displayName..."
        $createUri = "https://api.fabric.microsoft.com/v1/workspaces/$workspaceId/items"
        $body = @{
            displayName = $displayName
            type        = "DataPipeline"
            definition  = @{
                parts = @(
                    @{
                        path = "pipeline-content.json"
                        payload = $base64Content
                        payloadType = "Base64"
                    }
                )
            }
        } | ConvertTo-Json -Depth 10
        Invoke-RestMethod -Uri $createUri -Method Post -Headers $headers -Body $body
    } else {
        Write-Host "Data Pipeline '$displayName' already exists. Updating definition..."
        $itemId = $existing.id
        $updateUri = "https://api.fabric.microsoft.com/v1/workspaces/$workspaceId/items/$itemId/updateDefinition"
        $body = @{
            definition = @{
                parts = @(
                    @{
                        path = "pipeline-content.json"
                        payload = $base64Content
                        payloadType = "Base64"
                    }
                )
            }
        } | ConvertTo-Json -Depth 10
        Invoke-RestMethod -Uri $updateUri -Method Post -Headers $headers -Body $body
    }
}
