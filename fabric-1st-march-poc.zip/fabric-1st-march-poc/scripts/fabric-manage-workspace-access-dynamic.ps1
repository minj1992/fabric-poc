# fabric-manage-workspace-access-dynamic.ps1
# Purpose: Dynamically assign Workspace Roles in Microsoft Fabric with Conflict (409) handling
param (
    [string]$workspaceId,
    [string]$token,
    [string]$principalName,
    [string]$principalIdFromParam,
    [string]$principalType,
    [string]$role
)

$headers = @{
    Authorization = "Bearer $token"
    "Content-Type" = "application/json"
}

# 1. Resolve Principal ID
$principalId = $principalIdFromParam
if ([string]::IsNullOrWhiteSpace($principalId) -or $principalId -eq "NONE") {
    Write-Host "Attempting to resolve Object ID for ${principalType}: $principalName..."
    try {
        if ($principalType -eq "Group") {
            $principalId = az ad group show --group "$principalName" --query id -o tsv
        } elseif ($principalType -eq "User") {
            $principalId = az ad user show --id "$principalName" --query id -o tsv
        } elseif ($principalType -eq "ServicePrincipal") {
            $principalId = az ad sp list --display-name "$principalName" --query "[0].id" -o tsv
            if ([string]::IsNullOrWhiteSpace($principalId)) {
                $principalId = az ad sp show --id "$principalName" --query id -o tsv
            }
        }
    } catch {
        Write-Warning "Automatic lookup failed via Azure CLI. Using $principalName directly."
        $principalId = $principalName
    }
}

if ([string]::IsNullOrWhiteSpace($principalId) -or $principalId -eq "NONE") {
    Write-Error "Failed to resolve Principal ID."
    exit 1
}
Write-Host "Resolved Object ID: $principalId"

# 2. Check existing roles
Write-Host "Checking current role assignments for Workspace: $workspaceId..."
$uri = "https://api.fabric.microsoft.com/v1/workspaces/$workspaceId/roleAssignments"

$existing = $null
try {
    $currentRoles = Invoke-RestMethod -Uri $uri -Method Get -Headers $headers
    # Check if the principal already has *any* role in the workspace
    $existing = $currentRoles.value | Where-Object { $_.principal.id -eq $principalId }
} catch {
    Write-Warning "Could not fetch existing roles. Proceeding with assignment attempt."
}

if ($null -ne $existing) {
    if ($existing.role -eq $role) {
        Write-Host "Role $role already assigned to $principalName. Skipping."
        exit 0
    } else {
        Write-Host "Principal already has role '$($existing.role)'. Attempting update to '$role' via PATCH..."
        # Note: If Patch is not supported for roleAssignments, we may need to Delete and Post.
        # However, many Fabric APIs use 409 Conflict if they already exist.
        try {
            $updateUri = "$uri/$($existing.id)"
            Invoke-RestMethod -Uri $updateUri -Method Patch -Headers $headers -Body (@{ role = $role } | ConvertTo-Json)
            Write-Host "Role successfully updated."
            exit 0
        } catch {
            Write-Warning "PATCH update failed. Attempting POST as fallback."
        }
    }
}

# 3. Assign Role (POST)
Write-Host "Assigning $role role to $principalName ($principalId)..."
$body = @{
    principal = @{
        id = $principalId
        type = $principalType
    }
    role = $role
} | ConvertTo-Json

try {
    Invoke-RestMethod -Uri $uri -Method Post -Headers $headers -Body $body
    Write-Host "Role successfully assigned."
} catch {
    $statusCode = 0
    if ($null -ne $_.Exception.Response) { $statusCode = [int]$_.Exception.Response.StatusCode }
    
    if ($statusCode -eq 409) {
        Write-Host "SUCCESS: Role already exists or assignment already active (Conflict 409 caught)."
    } else {
        Write-Error "Failed to assign role (Status: $statusCode): $($_.Exception.Message)"
        if ($null -ne $_.ErrorDetails) { Write-Host "Details: $($_.ErrorDetails.Message)" }
        exit 1
    }
}
