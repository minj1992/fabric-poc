# logging_utils.py
# Purpose: Standardized logging and activity capturing for Fabric Notebooks

import time
import datetime
import json

def log_activity(activity_name, status, details=None, lakehouse=None):
    """
    Captures activity details and prints them in a structured format.
    In a real enterprise scenario, this would send logs to Azure Log Analytics / Application Insights.
    """
    log_entry = {
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "activity_name": activity_name,
        "status": status,
        "lakehouse": lakehouse,
        "details": details or {},
        "env": "DEV"
    }
    
    # Standard output for Azure Monitor to scrape
    print(f"ACTIVITY_LOG: {json.dumps(log_entry)}")
    
    # In Fabric, you can also log to a Delta table in the Lakehouse for audit history
    # log_df = spark.createDataFrame([log_entry])
    # log_df.write.format("delta").mode("append").saveAsTable("audit_logs")

def start_activity(activity_name, lakehouse=None):
    print(f"Starting activity: {activity_name}")
    log_activity(activity_name, "Started", lakehouse=lakehouse)
    return time.time()

def end_activity(activity_name, start_time, status="Success", details=None, lakehouse=None):
    duration = time.time() - start_time
    details = details or {}
    details["duration_seconds"] = round(duration, 2)
    print(f"Finished activity: {activity_name} in {details['duration_seconds']}s")
    log_activity(activity_name, status, details=details, lakehouse=lakehouse)
