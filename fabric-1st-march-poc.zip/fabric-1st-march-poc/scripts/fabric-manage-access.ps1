# fabric-manage-access.ps1
# Purpose: Assign Workspace Roles (Admin, Member, Contributor, Viewer) in Microsoft Fabric via REST API
param (
    [string]$workspaceId,
    [string]$token,
    [string]$configPath
)

$headers = @{
    Authorization = "Bearer $token"
    "Content-Type" = "application/json"
}

# 1. Load the access policy from config
if (-not (Test-Path $configPath)) {
    Write-Error "Access configuration file not found at: $configPath"
    exit 1
}
$config = Get-Content -Path $configPath | ConvertFrom-Json

# 2. Get current workspace role assignments
Write-Host "Fetching current role assignments for Workspace: $workspaceId..."
$uri = "https://api.fabric.microsoft.com/v1/workspaces/$workspaceId/roleAssignments"
$currentRoles = Invoke-RestMethod -Uri $uri -Method Get -Headers $headers

# 3. Apply policies (Idempotent: Create if missing)
foreach ($policy in $config.accessPolicies) {
    $principalName = $policy.principalName
    $principalType = $policy.principalType
    $role = $policy.role

    # Check if assignment already exists
    $existing = $currentRoles.value | Where-Object { $_.principal.displayName -eq $principalName -and $_.role -eq $role }

    if ($null -eq $existing) {
        $principalId = ""

        Write-Host "Attempting to automatically resolve Object ID for ${principalType}: $principalName..."
        try {
            if ($principalType -eq "Group") {
                $principalId = az ad group show --group "$principalName" --query id -o tsv
            } elseif ($principalType -eq "User") {
                $principalId = az ad user show --id "$principalName" --query id -o tsv
            } elseif ($principalType -eq "ServicePrincipal") {
                $principalId = az ad sp show --id "$principalName" --query id -o tsv
            }
        } catch {
            Write-Warning "Automatic lookup failed for $principalName (Insufficient Permissions). Trying config fallback..."
        }

        # If automatic lookup failed, check if ID is provided in config/JSON
        if ([string]::IsNullOrWhiteSpace($principalId)) {
            if (-not [string]::IsNullOrWhiteSpace($policy.principalId) -and $policy.principalId -ne "PASTE_GROUP_OBJECT_ID_HERE") {
                $principalId = $policy.principalId
                Write-Host "Using manual input ID from config for ${principalName}: $principalId"
            } else {
                Write-Warning "Could not resolve ID for $principalName and no ID found in config. Skipping assignment."
                continue
            }
        } else {
            Write-Host "Successfully resolved Object ID automatically: $principalId"
        }

        Write-Host "Assigning $role role to ${principalType}: $principalName ($principalId)..."
        
        $assignUri = "https://api.fabric.microsoft.com/v1/workspaces/$workspaceId/roleAssignments"
        $body = @{
            principal = @{
                id = $principalId
                type = $principalType
            }
            role = $role
        } | ConvertTo-Json

        Invoke-RestMethod -Uri $assignUri -Method Post -Headers $headers -Body $body
        Write-Host "Role assignment completed for $principalName."
    } else {
        Write-Host "Policy for $principalName ($role) is already in place. Skipping."
    }
}
