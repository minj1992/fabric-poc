# fabric-deploy-lakehouse.ps1
# Purpose: Idempotent Lakehouse creation in Microsoft Fabric via REST API
param (
    [string]$workspaceId,
    [string]$token,
    [string]$lakehousePath
)

$headers = @{
    Authorization = "Bearer $token"
    "Content-Type" = "application/json"
}

# 1. Get List of existing items
$uri = "https://api.fabric.microsoft.com/v1/workspaces/$workspaceId/items"
$response = Invoke-RestMethod -Uri $uri -Method Get -Headers $headers

# 2. Iterate through files in artifacts/lakehouse
$files = Get-ChildItem -Path $lakehousePath -Filter *.json
foreach ($file in $files) {
    $content = Get-Content -Path $file.FullName | ConvertFrom-Json
    $displayName = $content.displayName

    $existing = $response.value | Where-Object { $_.displayName -eq $displayName -and $_.type -eq "Lakehouse" }

    if ($null -eq $existing) {
        Write-Host "Creating Lakehouse: $displayName..."
        $createUri = "https://api.fabric.microsoft.com/v1/workspaces/$workspaceId/items"
        $body = @{
            displayName = $displayName
            type        = "Lakehouse"
        } | ConvertTo-Json
        Invoke-RestMethod -Uri $createUri -Method Post -Headers $headers -Body $body
    } else {
        Write-Host "Lakehouse '$displayName' already exists. Skipping creation."
    }
}
