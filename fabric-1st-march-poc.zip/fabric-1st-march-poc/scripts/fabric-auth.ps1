# fabric-auth.ps1
# Purpose: Authenticate and obtain Bearer Tokens for both Fabric Core and Power BI APIs
param (
    [string]$serviceConnectionName
)

Write-Host "Acquiring Token for Fabric Core API (api.fabric.microsoft.com)..."
$fabricToken = az account get-access-token --resource https://api.fabric.microsoft.com/ --query accessToken -o tsv

Write-Host "Acquiring Token for Power BI / Artifacts API (analysis.windows.net)..."
$pbiToken = az account get-access-token --resource https://analysis.windows.net/powerbi/api --query accessToken -o tsv

if ($null -eq $fabricToken -or $null -eq $pbiToken) {
    Write-Error "Failed to acquire one or more access tokens via Azure CLI."
    exit 1
}

# Export both as output variables
Write-Host "##vso[task.setvariable variable=FABRIC_CORE_TOKEN;isOutput=true;issecret=true]$fabricToken"
Write-Host "##vso[task.setvariable variable=PBI_TOKEN;isOutput=true;issecret=true]$pbiToken"

# For backward compatibility, map one to FABRIC_TOKEN
Write-Host "##vso[task.setvariable variable=FABRIC_TOKEN;isOutput=true;issecret=true]$fabricToken"

Write-Host "Auth Tokens successfully acquired and masked."
