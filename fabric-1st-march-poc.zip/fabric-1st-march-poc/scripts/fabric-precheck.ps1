# fabric-precheck.ps1
# Purpose: Validate Workspace ID using explicit Bearer tokens
param (
    [string]$workspaceName,
    [string]$token
)

$headers = @{
    Authorization = "Bearer $token"
    "Content-Type" = "application/json"
}

Write-Host "Searching for Workspace: $workspaceName"
$uri = "https://api.fabric.microsoft.com/v1/workspaces"

try {
    $response = Invoke-RestMethod -Uri $uri -Method Get -Headers $headers
    $workspace = $response.value | Where-Object { $_.displayName -eq $workspaceName }
} catch {
    Write-Error "Failed to connect to Fabric API: $($_.Exception.Message)"
    exit 1
}

if ($null -eq $workspace) {
    Write-Warning "Workspace '$workspaceName' not found in the list."
    Write-Host "Available Workspaces for this Service Principal:"
    $response.value | ForEach-Object { Write-Host "- $($_.displayName) (ID: $($_.id))" }
    Write-Error "Workspace validation failed."
    exit 1
}

$workspaceId = $workspace.id
Write-Host "##vso[task.setvariable variable=WORKSPACE_ID;isOutput=true]$workspaceId"
Write-Host "Found Workspace ID: $workspaceId"
Write-Host "Pre-check passed successfully."
