-- config_db_schema.sql
-- Purpose: Schema for the metadata-driven orchestration (Config DB) in Azure SQL

-- 1. Metadata for Pipelines
CREATE TABLE [dbo].[PipelineMetadata] (
    [PipelineID] INT PRIMARY KEY IDENTITY(1,1),
    [PipelineName] VARCHAR(255) NOT NULL,
    [Domain] VARCHAR(50) NOT NULL,
    [Entity] VARCHAR(100) NOT NULL,
    [SourcePath] VARCHAR(500),
    [TargetTable] VARCHAR(255),
    [Layer] VARCHAR(50), -- Raw, Curated, Entity, Value
    [IsActive] BIT DEFAULT 1
);

-- 2. Runtime Activity Logging
CREATE TABLE [dbo].[ActivityLog] (
    [LogID] BIGINT PRIMARY KEY IDENTITY(1,1),
    [RunID] VARCHAR(100),
    [ActivityName] VARCHAR(255),
    [Workspace] VARCHAR(100) DEFAULT 'P3-DEV-POC',
    [StartTime] DATETIME2,
    [EndTime] DATETIME2,
    [Status] VARCHAR(50), -- Started, Success, Failed
    [Details] NVARCHAR(MAX),
    [ProcessedCount] INT
);

-- 3. Environment Config
CREATE TABLE [dbo].[EnvironmentConfig] (
    [EnvID] INT PRIMARY KEY IDENTITY(1,1),
    [WorkspaceName] VARCHAR(100),
    [CapacityID] VARCHAR(100),
    [LakehousePath] VARCHAR(500)
);

-- Sample Metadata for Claims
INSERT INTO [dbo].[PipelineMetadata] (PipelineName, Domain, Entity, Layer)
VALUES 
('NB_CLAIMS_RAW_LOAD', 'Claims', 'Provider', 'Raw'),
('NB_CLAIMS_CURATED_LOAD', 'Claims', 'Provider', 'Curated');
