# create_lakehouse_structure.py
# Purpose: Create the standard folder and table structure in Microsoft Fabric Lakehouses

import notebookutils
from pyspark.sql import SparkSession

def create_lakehouse_folders(lakehouse_name):
    """Creates the standard folders in the specified Lakehouse."""
    base_path = f"Files"
    folders = ["landing", "raw", "processed", "archive"]

    for folder in folders:
        folder_path = f"{base_path}/{folder}"
        print(f"Checking/Creating folder: {folder_path} in {lakehouse_name}")
        # Use mssparkutils or notebookutils to create directories
        try:
            notebookutils.fs.mkdirs(folder_path)
            print(f"Successfully created: {folder_path}")
        except Exception as e:
            print(f"Folder already exists or error: {str(e)}")

def create_medallion_tables(lakehouse_name, entities):
    """Creates placeholder medallion tables for a given domain/entities."""
    layers = ["bronze", "silver", "gold"]

    for entity in entities:
        for layer in layers:
            table_name = f"{layer}_{entity}"
            print(f"Creating placeholder table: {table_name} in {lakehouse_name}")
            # Conceptual table creation if it doesn't exist
            # spark.sql(f"CREATE TABLE IF NOT EXISTS {table_name} USING delta")

if __name__ == "__main__":
    spark = SparkSession.builder.getOrCreate()
    
    # 1. Define Lakehouse and Entities (Example for Claims)
    current_lakehouse = "LH_Claims"
    domain_entities = ["claims", "payments"]

    # 2. Setup Folders
    create_lakehouse_folders(current_lakehouse)

    # 3. Setup Tables
    create_medallion_tables(current_lakehouse, domain_entities)

    print("Lakehouse structure setup completed.")
