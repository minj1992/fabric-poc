# Enterprise Fabric POC

This project demonstrates a scalable, enterprise-grade architecture for **Microsoft Fabric** integrated with **Azure DevOps**.

## Documentation Links

- [./docs/feature.md](./docs/feature.md): Overview of features and Medallion architecture.
- [./docs/workflow.md](./docs/workflow.md): Detailed deployment and data workflows.
- [./docs/troubleshooting.md](./docs/troubleshooting.md): Troubleshooting common deployment and runtime issues.
- [./docs/architecture.md](./docs/architecture.md): Full architecture blueprint and diagrams.
- [./docs/deployment-blueprint.md](./docs/deployment-blueprint.md): Automation blueprint for CI/CD.

## Deployment Sequence (Trigger Order)

For a successful enterprise deployment, trigger the pipelines in this specific order:

1.  **Step 1: Capacity Deployment**
    *   **Pipeline**: `AZDP_FABRIC_CAPACITY_DEPLOY.yml`
    *   **Action**: Creates the F2 Fabric Capacity and sets the capacity admin.
2.  **Step 2: Workspace & Security Deployment**
    *   **Pipeline**: `AZDP_FABRIC_WORKSPACE_DEPLOY.yml`
    *   **Action**: Creates the `P3-DEV-POC` workspace, links it to the F2 capacity, and assigns the Security Groups (`SG_FABRIC_P3_DEV_ADMIN`, etc.).
3.  **Step 3: Artifact Deployment (CI/CD)**
    *   **Pipeline**: `AZDP_FABRIC_ARTIFACT_DEPLOY.yml`
    *   **Action**: Deploys the Lakehouses, Notebooks, and Data Pipelines into the workspace.
4.  **Step 4: Resource Control (Optional/Ongoing)**
    *   **Pipeline**: `AZDP_FABRIC_CAPACITY_CONTROL.yml`
    *   **Action**: Use this to **Resume** (Start) or **Suspend** (Pause) the capacity to manage costs.

## Getting Started

1. Set up Azure DevOps repository.
2. Configure **network360** service connection.
3. Use **ubuntu-latest** for build agents.
4. Execute the infrastructure pipelines in order.
