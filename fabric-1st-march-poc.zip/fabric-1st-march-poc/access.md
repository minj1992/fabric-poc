# Microsoft Fabric Enterprise Access Management

This document provides a technical overview of the **Hybrid Multi-API Access Orchestration** framework used for managing security in the Microsoft Fabric environment.

## 📂 Directory Structure
```text
.
├── pipelines
│   └── AZDP_FABRIC_ACCESS_MANAGEMENT.yml  # Master UI & Stage Orchestrator
├── scripts
│   ├── fabric-auth.ps1                    # Bearer Token Acquisition
│   ├── fabric-precheck.ps1                # Workspace ID Discovery & Validation
│   ├── fabric-manage-workspace-access-dynamic.ps1 # Granular Workspace Role Assignment
│   └── fabric-manage-item-access.ps1      # MASTER ITEM-LEVEL ACCESS ORCHESTRATOR
└── access.md                              # Technical Documentation
```

## 🔄 Hybrid Strategy Pipeline Workflow
This diagram illustrates how the orchestrator navigates between item-level REST calls and Workspace Role fallbacks.

```text
[ Azure DevOps UI: Select Item & Permissions ]
           |
           V
[ Authenticate & Resolve Object ID (SPN/User/Group) ]
           |
           V
[ Discovery: Resolve Item ID & Related Artifacts ]
           |
           V
[ Step 1: Item-Level REST Alignment ]
   |-- 1st: Fabric Core V1 (/permissions)
   |-- 2nd: PBI Datasets Fallback (datasetUserAccessRight)
   |-- 3rd: PBI Artifacts Fallback (artifactUserAccessRight)
           |
   [ IF ALL FAIL? ]
           |
   [ Step 2: Workspace Role Fallback (if enabled) ]
           |-- Assign 'Contributor' or 'Viewer'
           |-- Inherit granular rights automatically
           |
           V
[ FINAL: Validation & Conflict (409) Handling ]
```

## 🛠️ Master REST API Reference Table
| Artifact Type | API Provider | Endpoint Template | Reliability |
| :--- | :--- | :--- | :--- |
| **Lakehouse** | Power BI | `/myorg/groups/{workspaceId}/datasets/{itemId}/users` | 100% |
| **Notebook** | Power BI | `/myorg/groups/{workspaceId}/artifacts/{itemId}/users` | 90% |
| **DataPipeline**| Fabric Core | `/v1/workspaces/{workspaceId}/items/{itemId}/permissions`| 70% |
| **Workspace** | Fabric Core | `/v1/workspaces/{workspaceId}/roleAssignments` | 100% |

## 🔑 Technical Function Call Hierarchy
- **`AZDP_FABRIC_ACCESS_MANAGEMENT.yml`**: Top-level stage orchestration and fallback logic trigger.
- **`fabric-manage-item-access.ps1`**: Resolves identities, discovers related items (SQL Endpoint), and loops through REST strategies.
- **`Align-Permissions` (Inner Function)**: Performs the actual GET/POST/PATCH calls with idempotency checking.
- **`fabric-manage-workspace-access-dynamic.ps1`**: Handles fallback role assignment with 409 Conflict suppression.

## 📝 Permission Mapping Reference (Lakehouse)
Use this set for full contributor-level access to a Lakehouse and its SQL Endpoint:
`Read, Write, Reshare, Execute, ReadAll, ViewOutput, ViewLogs, SubscribeOneLakeEvents`


## 📋 Technical Function & Script Hierarchy
| Layer | Script / Function | Primary Purpose |
| :--- | :--- | :--- |
| **Orchestration** | `AZDP_FABRIC_ACCESS_MANAGEMENT.yml` | UI input handling, staging, and fallback logic. |
| **Logic** | `fabric-manage-item-access.ps1` | Principal resolution, item discovery, and strategy looping. |
| **Utility** | `Align-Permissions` (Function) | Internal logic for POST/PATCH attempts with 409 suppression. |
| **Role Mgmt** | `fabric-manage-workspace-access-dynamic.ps1` | Direct Workspace Role Assignment (Admin/Member/Contributor/Viewer). |
| **Auth** | `fabric-auth.ps1` | Scoped token acquisition for `api.fabric.microsoft.com`. |

## 🛠️ REST API List
The orchestrator uses the following API endpoints dynamically:

| API Provider | Endpoint Pattern | Method | Purpose |
| :--- | :--- | :--- | :--- |
| **Fabric Core** | `/v1/workspaces/{id}/roleAssignments` | GET/POST | Workspace Role Management |
| **Fabric Core** | `/v1/workspaces/{id}/items/{id}/permissions` | GET/POST | Granular Item Permissions |
| **PBI Datasets** | `/v1.0/myorg/groups/{id}/datasets/{id}/users` | POST | Lakehouse Permission Fallback |
| **PBI Artifacts** | `/v1.0/myorg/groups/{id}/artifacts/{id}/users`| POST | Notebook/Artifact Fallback |

## 🔑 Key Features
1. **Idempotency (GET-before-POST)**: Every script checks if a permission already exists before attempting an assignment.
2. **409 Conflict Suppression**: Automatically detects "Conflict" status and treats it as a success if the permission is already present.
3. **Deep Discovery**: Automatically identifies and secures the **SQL Endpoint** and **Default Semantic Model** when a Lakehouse is targeted.
4. **Resilient Fallback**: Automatically escalates to a Workspace Role (e.g., Contributor) if item-level APIs are unavailable.
5. **Principal Resolution**: Seamlessly handles User Emails, Group Names, and Service Principal IDs.
