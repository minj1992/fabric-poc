# Enterprise Fabric POC Features

This POC implements a standardized, enterprise-grade architecture for data engineering in Microsoft Fabric.

## Key Features

- **Domain Isolation**: 4 Domain Lakehouses for data segregation:
  - `LH_Claims`: Claims data management.
  - `LH_Providers`: Provider directory and data.
  - `LH_Members`: Member information.
  - `LH_ReferenceData`: Reference data shared across domains.
- **Medallion Architecture**: Standardized data processing across 3 layers:
  - `bronze_<entity>`: Raw data ingestion.
  - `silver_<entity>`: Cleansed and transformed data.
  - `gold_<entity>`: Business-ready data for reporting.
- **CI/CD Integration**: Fully automated deployment using Azure DevOps pipelines:
  - **Infrastructure as Code (IaC)**: Deploying Fabric Capacity and Workspace.
  - **Artifact Deployment**: CI/CD for Lakehouses, Notebooks, and Pipelines.
- **Security & Governance**: Managed via Azure AD groups (SG_FABRIC_P3_DEV_ADMIN, etc.).
- **Folder Standards**: Consistent directory structure inside each Lakehouse:
  - `/Files/landing`
  - `/Files/raw`
  - `/Files/processed`
  - `/Files/archive`
- **Standardized Naming**: Clear and consistent naming for all Fabric artifacts.
