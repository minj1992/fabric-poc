# Deployment Automation Blueprint

This document outlines the CI/CD strategy for the Microsoft Fabric Enterprise POC.

## Infrastructure as Code (IaC)

1. **Capacity Deployment**: Uses ARM/Bicep template to create the Fabric Capacity.
   - Pipeline: `AZDP_FABRIC_CAPACITY_DEPLOY.yml`
   - Agent: `ubuntu-latest`
   - Service Connection: `network360`
2. **Workspace Deployment**: Uses Fabric REST API to create the workspace and link to capacity.
   - Pipeline: `AZDP_FABRIC_WORKSPACE_DEPLOY.yml`
   - Security: AD Groups assigned via REST API.

3. **Resource Control (Pause/Start)**: Manages cost by suspending/resuming capacity.
   - Pipeline: `AZDP_FABRIC_CAPACITY_CONTROL.yml`
   - Action: `Resume` or `Suspend`.


## Step-by-Step Execution Guide

To deploy the full enterprise environment, trigger the following pipelines in order:

| Step | Pipeline Name | Purpose |
| :--- | :--- | :--- |
| **1** | `AZDP_FABRIC_CAPACITY_DEPLOY.yml` | **Infrastructure Start**: Deploys the F2 capacity. |
| **2** | `AZDP_FABRIC_WORKSPACE_DEPLOY.yml` | **Workspace Setup**: Creates `P3-DEV-POC` and assigns Security Groups. |
| **3** | `AZDP_FABRIC_ARTIFACT_DEPLOY.yml` | **Deployment**: Pushes Lakehouses, Notebooks, and Pipelines into the workspace. |
| **4** | `AZDP_FABRIC_CAPACITY_CONTROL.yml` | **Maintenance**: Start or Stop the capacity based on usage needs. |

## Artifact CI/CD (DevOps to Fabric)

The `AZDP_FABRIC_ARTIFACT_DEPLOY.yml` pipeline automates the deployment of:

- **Lakehouses**: `LH_Claims`, `LH_Providers`, `LH_Members`, `LH_ReferenceData`.
- **Notebooks**: Version-controlled in Git and imported into the workspace.
- **Data Pipelines**: Orchestration logic deployed via JSON definitions.

## GitHub/Azure DevOps Integration

- **Git Integration**: Enable Fabric Git integration in the workspace settings.
- **Branching Strategy**: 
  - `feature/*`: Development and unit testing.
  - `main`: Triggers deployment to the development environment.
- **Service Principal**: Use a Service Principal with the `network360` connection to authenticate.
