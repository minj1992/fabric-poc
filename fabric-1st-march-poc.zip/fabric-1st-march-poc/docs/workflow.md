# Enterprise Fabric POC Workflow

This document describes the end-to-end workflow for deploying and running the Microsoft Fabric Enterprise POC.

## Pipeline Deployment Workflow (Azure DevOps)

The following diagram shows the sequential deployment of the Enterprise Fabric architecture.

```text
+-----------------------+      +-----------------------+      +-----------------------+
|                       |      |                       |      |                       |
|  Pipeline 1:          |      |  Pipeline 2:          |      |  Pipeline 3:          |
|  Capacity Deployment  |----->|  Workspace & Security |----->|  Artifact Deployment  |
|                       |      |                       |      |                       |
+-----------------------+      +-----------------------+      +-----------------------+
|  Agent: ubuntu-latest |      |  Agent: ubuntu-latest |      |  Agent: ubuntu-latest |
|  SC: network360       |      |  SC: network360       |      |  SC: network360       |
+-----------------------+      +-----------------------+      +-----------------------+
```

## Fabric Architecture Workflow (Enterprise Medallion)

The flow of data through the 4-layer Medallion architecture:

```text
+----------------+      +------------------+      +------------------+      +------------------+      +------------------+
|                |      |                  |      |                  |      |                  |      |                  |
|  Data Sources  |----->|  Raw Layer       |----->|  Curated Layer   |----->|  Entity Layer    |----->|  Value Layer     |
|  (SaaS, SQL)   |      |  (Bronze - 1:1)  |      |  (Silver - DQ)   |      |  (Gold - Domain) |      |  (Gold - Value)  |
|                |      |                  |      |                  |      |                  |      |                  |
+----------------+      +------------------+      +------------------+      +------------------+      +------------------+
      Phase 1          Engineering WS            Engineering WS            Domain WS                Domain WS
    Ingestion          Full Dataset              Type 2 History            Common Taxonomy          Data Products
```

## Capacity and Workspace Hierarchy

The hierarchical structure of the Enterprise Fabric deployment:

```text
+-------------------------------------------------------+
|                                                       |
|  Fabric Capacity (F2)                                 |
|  (Service Connection: network360)                      |
|                                                       |
|  +-------------------------------------------------+  |
|  |                                                 |  |
|  |  Workspace: P3-DEV-POC                           |  |
|  |                                                 |  |
|  |  +-----------------+ +-----------------+        |  |
|  |  | LH_Claims       | | LH_Providers    |        |  |
|  |  +-----------------+ +-----------------+        |  |
|  |  | LH_Members      | | LH_ReferenceData|        |  |
|  |  +-----------------+ +-----------------+        |  |
|  |                                                 |  |
|  +-------------------------------------------------+  |
|                                                       |
+-------------------------------------------------------+
```

## Data Integration Workflow (Metadata Driven)

1. **Ingest (Phase 1)**: Data is captured from SaaS/SQL sources, validated, and dumped into `/Files/landing`.
2. **Metadata Lookup**: Notebook retrieves its execution context (Entity, Source, Target) from the `Config DB` (`PipelineMetadata`).
3. **Raw (Engineering)**: Metadata-driven pipelines load data into the **Raw Layer** as 1:1 source objects with audit columns.
4. **Activity Start**: Every notebook logs "Started" in the `ActivityLog` table.
5. **Curate (Engineering)**: Data is transformed, typed, and quality-enforced in the **Curated Layer** (SCD Type 2 supported).
6. **Entity (Domain)**: Business logic is applied to create common taxonomies in the **Entity Layer**.
7. **Value (Domain)**: Final data products (Visit Mart, etc.) are modeled in the **Value Layer** for PowerBI and Analytics.
8. **Activity End**: Final execution status is updated in the `ActivityLog`.
