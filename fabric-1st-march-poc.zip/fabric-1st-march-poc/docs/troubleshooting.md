# Troubleshooting Guide

This guide provides solutions to common issues encountered in the Enterprise Fabric POC.

## Pipeline Failures

### Resource Group Check Failure
- **Error**: `Failed to check the resource group status. Error: {"statusCode":400}.`
- **Resolution**: 
  - Ensure the pipeline variable `SUBSCRIPTION_ID` is defined in the Azure DevOps Pipeline (Variables tab or Library). 
  - Verify that the Service Connection `network360` has **Contributor** or **Owner** access at the **Subscription level** (required for creating/checking resource groups).
  - Check that the `subscriptionId` matches the target subscription.

### Agent Issues
- **Error**: `Agent Pool 'Hosted Ubuntu 1804' not available.`
- **Resolution**: Ensure that the pipeline is using `ubuntu-latest`.

## Fabric Deployment Issues

### Capacity Deployment
- **Error**: `Capacity SKU not supported.`
- **Resolution**: Check the SKU specified in the deployment parameters and ensure it is available in the region.

### Fabric REST API: Unauthorized Error
- **Error**: `errorCode: Unauthorized, message: The caller is not authenticated to access this resource`
- **Resolution**: 
  1. **Enable Service Principal Access**: Go to the **Fabric Admin Portal** -> **Tenant Settings** -> Search for **"Service principals can use Fabric APIs"** and ensure it is **Enabled** (at least for the security group containing your SP).
  2. **Capacity Permissions**: The Service Principal (the one used in `network360`) must be an **Admin** of the Fabric Capacity. 
     - Go to the **Azure Portal** -> Your Capacity -> **Fabric administrators**.
     - Add the **Object ID** or **Name** of your Service Principal here.
  3. **Power BI Admin Settings**: If creating workspaces, ensure **"Create workspaces"** is enabled for Service Principals in the Power BI/Fabric admin portal settings.

### Scheduled Pipeline Not Running
- **Symptoms**: The capacity doesn't start at 9AM or stop at 7PM IST.
- **Resolution**: 
  1. **Default Branch Requirement**: Azure DevOps only processes YAML schedules on the **default branch** (usually `main`). Ensure the YAML file is committed to your default branch.
  2. **Enable Triggers**: Go to the pipeline settings in Azure DevOps and verify that "Scheduled triggers" are not disabled.
  3. **Check Logic**: The pipeline uses `$(Build.CronSchedule.DisplayName)` to decide whether to Start or Stop. If you trigger it manually, ensure you select **Resume** or **Suspend** instead of "Auto" if it's not currently at the 9AM/7PM window.
