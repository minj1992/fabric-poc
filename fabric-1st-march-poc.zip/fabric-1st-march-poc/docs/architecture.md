# Enterprise Fabric Architecture

This document provides a full architecture overview for the Microsoft Fabric Enterprise POC.

## 1. Governance & Hierarchy

- **Fabric Capacity**: Dedicated F2 Capacity for performance and scalability.
- **Workspace**: `P3-DEV-POC` (Standardized workspace naming).
- **Domains**: 4 Domain-specific Lakehouses (`LH_Claims`, `LH_Providers`, etc.).

## 2. Data Platform Framework (Enterprise Medallion)

All data processing follows an advanced enterprise medallion pattern based on the Data Platform Framework:

### Engineering Workspace (Central)
- **Raw Layer (Bronze)**: 
  - 1:1 Source Object mapping.
  - Full Dataset (Append Only).
  - Includes Audit Columns (Ingestion Timestamps, Source IDs).
  - Uses Delta & External Tables.
  - **Consumption**: No direct business consumption.
- **Curated Layer (Silver)**:
  - 1:1 Raw Object mapping.
  - Supports Type 2 History (SCD Type 2).
  - Data Quality Enforced (Constraints & Validation).
  - Cleaned & Data Typed.
  - **Consumption**: Limited consumption for data engineering.

### Domain Workspace(s) (Business Specific)
- **Entity Layer (Gold - Shared)**:
  - N:1 Entities (Joining multiple curated sources).
  - Common Taxonomy (Enterprise Data Model).
  - Data Quality Verified for business rules.
  - Common Business Logic Applied.
  - **Consumption**: Full consumption for downstream marts.
- **Value Layer (Gold - Final)**:
  - Business Value based Objects (Visit Mart, Member Churn, Hedis).
  - Data Products (Full Modeled).
  - Optimized for PowerBI / SQL Warehouse.
  - **Consumption**: Full consumption for Analysis & Reporting.

## 3. Metadata Driven Orchestration (Config DB)

- **Template Based Pipelines**: All pipelines are driven by metadata stored in a central `Config DB` (Azure SQL).
  - Table: `PipelineMetadata` defines sources, targets, and layers for the medallion architecture.
  - Integration: Notebooks dynamically pull parameters (Lakehouse, Entity, Layer) based on the current run context.
- **Automation**: Automatic generation of Spark Notebook parameters and folder paths.
- **Observability & Activity Tracking**: 
  - **Activity Log**: Every notebook and pipeline action is captured in the `ActivityLog` table.
  - **Details Captured**: Start Time, End Time, Status (Started/Success/Failed), Run ID, and Workspace (`P3-DEV-POC`).
  - **Azure Monitor**: Integration for real-time alerting on failed activities.

## 4. DevOps Integration

- **Agent**: `ubuntu-latest`
- **Service Connection**: `network360`
- **Pipelines**: 
  1. `AZDP_FABRIC_CAPACITY_DEPLOY.yml`
  2. `AZDP_FABRIC_WORKSPACE_DEPLOY.yml`
  3. `AZDP_FABRIC_ARTIFACT_DEPLOY.yml`

## 5. Security Framework

Security is managed via Azure AD Groups:
- **SG_FABRIC_P3_DEV_ADMIN**: Full workspace and capacity management.
- **SG_FABRIC_P3_DEV_CONTRIBUTOR**: Developer access to artifacts and notebooks.
- **SG_FABRIC_P3_DEV_VIEWER**: Read-only access for business analysts.

## 6. Folder Hierarchy (Internal Lakehouse)

```text
/Files/
├── landing/   <-- Initial source ingestion
├── raw/       <-- Raw copy of data
├── processed/ <-- Staging for transformations
└── archive/   <-- Processed file history
```

## 7. Pipeline Orchestration

- **Domain Pipelines**: `PL_CLAIMS_MAIN`, `PL_PROVIDERS_MAIN`, `PL_MEMBERS_MAIN`, `PL_REFERENCEDATA_MAIN`.
- **Dependency Flow**: Bronze NB -> Silver NB -> Gold NB.

## 8. Enterprise Platform Services (Shared)

- **Microsoft Entra ID**: Identity & Access Management.
- **Microsoft Purview**: Data Discovery, Governance & Compliance.
- **Azure KeyVault**: Centralized Secret Management for data connections.
- **Azure Monitor**: End-to-end Observability and logging.
- **Azure Cost Management**: Tracking Fabric and Compute spending.
- **Recovery Services**: Business Continuity & Disaster Recovery.

